""" Units and physical constants """
import sys
import numpy as np
from types import SimpleNamespace

# initialize data struct
data = SimpleNamespace(
  name = [],
  symbol = [],
  value = [],
  L = [],
  M = [],
  T = []
)

# read data
with open("const.txt", "r") as f:
  lines = f.readlines()

# populate data struct
num_const = 0
for line in lines[1:]:
  line_split = line.split(",")
  data.name.append(line_split[0].strip())
  data.symbol.append(line_split[1].strip())
  data.value.append(float(line_split[2].strip()))
  data.L.append(float(line_split[3].strip()))
  data.M.append(float(line_split[4].strip()))
  data.T.append(float(line_split[5].strip()))
  num_const += 1

def get_unit(length_unit, mass_unit, time_unit):

  unit = SimpleNamespace()
  unit.length = length_unit
  unit.mass = mass_unit
  unit.time = time_unit
  unit.velocity = unit.length / unit.time
  unit.density = unit.mass / unit.length**3
  unit.energy = unit.mass * unit.velocity**2
  unit.energy_density = unit.energy / unit.length**3

  for i in range(num_const):
    unit_const = unit.length**data.L[i] * unit.mass**data.M[i] * unit.time**data.T[i]
    setattr(unit, data.symbol[i] + "_unit", unit_const)
    setattr(unit, data.symbol[i], data.value[i] / unit_const)

  return unit

cgs = get_unit(1.0, 1.0, 1.0)
mks = get_unit(1e2, 1e3, 1.0)
