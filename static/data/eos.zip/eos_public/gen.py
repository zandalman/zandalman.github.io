""" Generate EOS tables from the partition function in Tomida+2013 (arxiv 1206.3567)"""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.colors import LinearSegmentedColormap
from scipy.optimize import approx_fprime
from scipy.special import logsumexp
from scipy.optimize import root_scalar
from scipy.interpolate import RegularGridInterpolator
from types import SimpleNamespace
from const import cgs

# custom colormaps
cmap_pnts = (np.array([1.0, 1.2, 4/3, 7/5, 1.6, 5/3]) - 1.0) / (5/3 - 1.0)
cmap_colors = ["white", "thistle", "powderblue", "limegreen", "gold", "tomato"]
cmap_pairs = list(zip(cmap_pnts, cmap_colors))
cmap_gam = LinearSegmentedColormap.from_list("gam", cmap_pairs, N=1024)

def get_cmap_mmw(Y=0.3):
  """ 
  Compute a custom colormap for the mean molecular weight. 
  
  Args
  Y: Helium mass fraction
  """
  mmw1 = 1 / ((1 - Y) * 2 + Y * 3/4)
  mmw2 = 1 / ((1 - Y) * 2 + Y * 2/4)
  mmw3 = 1 / ((1 - Y) * 2 + Y * 1/4)
  mmw4 = 1 / ((1 - Y) + Y * 1/4)
  mmw5 = 1 / ((1 - Y) * 1/2 + Y * 1/4)

  cmap_pnts = (np.array([0.6, mmw1, mmw2, mmw3, mmw4, mmw5, 2.4]) - 0.6) / (2.4 - 0.6)
  cmap = mpl.colormaps['turbo']
  cmap_colors = cmap(np.concatenate(([0], np.linspace(0.05, 0.95, 5), [1])))
  cmap_pairs = list(zip(cmap_pnts, cmap_colors))
  cmap_mmw = LinearSegmentedColormap.from_list("mmw", cmap_pairs, N=1024)

  return cmap_mmw

# math constants
log2 = np.log(2)
log3 = np.log(3)

# log molecular weights
log_m_H2 = np.log(2.01588 * cgs.amu)   # molecular Hydrogen
log_m_H = np.log(1.00794 * cgs.amu)    # atomic Hydrogen
log_m_He = np.log(4.002602 * cgs.amu)  # Helium
log_m_e = np.log(cgs.m_e)              # electron

# physical constants
logkB = np.log(cgs.k_B) # log Boltzman constant
logmp = np.log(cgs.m_p) # log proton mass
logarad = np.log(cgs.a) # log radiation constant
th_rot = 170.64         # excitation temperature of rotation
th_vib = 5984.48        # excitation temperature of vibration
chi_dis = 7.17e-12      # dissociation energy of H2
chi_ion = 2.18e-11      # ionization energy of HI
chi_HeI = 3.94e-11      # ionization energy of HeI
chi_HeII = 8.72e-11     # ionization energy of HeII
log_tr = np.log(2*np.pi * cgs.k_B / cgs.h**2) # useful to precompute for translational partition functions

# species indices
NSPEC = 7
H2, HI, HII, HeI, HeII, HeIII, elec = 0, 1, 2, 3, 4, 5, 6

def calc_log_Z_rot(temp, j):
  """ Compute the log H2 partition function for one rotational mode (Eq. 48-49 summand). """
  ener_rot = (j * (j + 1)) * th_rot / (2 * temp)
  log_g = np.log(2 * j + 1)
  return logsumexp(log_g - ener_rot)

def calc_log_Z_H2(log_temp, jmax):
  """ Compute the log H2 partition function (Eq. 46-52). """
  temp = np.exp(log_temp)
  log_Z_tr = 3/2 * (log_tr + log_m_H2 + log_temp)
  j_even = 2 * np.arange(jmax)
  j_odd = j_even + 1
  log_Z_rot_even = calc_log_Z_rot(temp, j_even)
  log_Z_rot_odd = calc_log_Z_rot(temp, j_odd) 
  log_Z_rot = 1/4 * log_Z_rot_even + 3/4 * (log3 + log_Z_rot_odd + th_rot / temp)
  log_Z_vib = -th_vib / (2 * temp) - np.log1p(-np.exp(-th_vib / temp))
  log_Z_spin = 2 * log2
  log_Z_elec = log2
  return log_Z_tr + log_Z_rot + log_Z_vib + log_Z_spin + log_Z_elec

def calc_log_Z_HI(log_temp):
  """ Compute the log HI partition function (Eq. 53-55). """
  temp = np.exp(log_temp)
  log_Z_tr = 3/2 * (log_tr + log_m_H + log_temp)
  log_Z_spin = log2
  log_Z_elec = log2 - chi_dis / (2 * cgs.k_B * temp)
  return log_Z_tr + log_Z_spin + log_Z_elec
    
def calc_log_Z_HII(log_temp):
  """ Compute the log HII partition function (Eq. 56-58). """
  temp = np.exp(log_temp)
  log_Z_tr = 3/2 * (log_tr + log_m_H + log_temp)
  log_Z_spin = log2
  log_Z_elec = log2 - (chi_dis + 2 * chi_ion) / (2 * cgs.k_B * temp)
  return log_Z_tr + log_Z_spin + log_Z_elec
    
def calc_log_Z_HeI(log_temp):
  """ Compute the log HeI partition function (Eq. 59). """
  log_Z_tr = 3/2 * (log_tr + log_m_He + log_temp)
  return log_Z_tr

def calc_log_Z_HeII(log_temp):
  """ Compute the log HeII partition function (Eq. 60-61). """
  temp = np.exp(log_temp)
  log_Z_tr = 3/2 * (log_tr + log_m_He + log_temp)
  log_Z_elec = -chi_HeI / (cgs.k_B * temp)
  return log_Z_tr + log_Z_elec

def calc_log_Z_HeIII(log_temp):
  """ Compute the log HeIII partition function (Eq. 62-63). """
  temp = np.exp(log_temp)
  log_Z_tr = 3/2 * (log_tr + log_m_He + log_temp)
  log_Z_elec = -(chi_HeI + chi_HeII) / (cgs.k_B * temp)
  return log_Z_tr + log_Z_elec

def calc_log_Z_elec(log_temp):
  """ Compute the log electron partition function (Eq. 64-65). """
  log_Z_tr = 3/2 * (log_tr + log_m_e + log_temp)
  log_Z_spin = log2
  return log_Z_tr + log_Z_spin

def calc_log_Z(log_temp, jmax):
  """ Compute the log partition function. """
  return np.array([
    calc_log_Z_H2(log_temp, jmax),
    calc_log_Z_HI(log_temp),
    calc_log_Z_HII(log_temp),
    calc_log_Z_HeI(log_temp),
    calc_log_Z_HeII(log_temp),
    calc_log_Z_HeIII(log_temp),
    calc_log_Z_elec(log_temp)
  ])

def calc_dlog_Z_rot(temp, j):
  """ Compute the log temperature derivative of the log H2 partition function for one rotational mode. """
  ener_rot = j * (j + 1) * th_rot / (2 * temp)
  log_g = np.log(2 * j + 1)
  fac = np.exp(log_g - ener_rot)
  return np.sum(ener_rot * fac) / np.sum(fac)

def calc_dlog_Z_H2(log_temp, jmax):
  """ Compute the log temperature derivative of the log H2 partition function. """
  temp = np.exp(log_temp)
  dlog_Z_tr = 3/2
  j_even = 2 * np.arange(jmax)
  j_odd = j_even + 1
  dlog_Z_rot_even = calc_dlog_Z_rot(temp, j_even)
  dlog_Z_rot_odd = calc_dlog_Z_rot(temp, j_odd)
  dlog_Z_rot = 1/4 * dlog_Z_rot_even + 3/4 * (dlog_Z_rot_odd - th_rot / temp)
  dlog_Z_vib = th_vib / (2 * temp) / np.tanh(th_vib / (2 * temp))
  return dlog_Z_tr + dlog_Z_rot + dlog_Z_vib

def calc_dlog_Z_HI(log_temp):
  """ Compute the log temperature derivative of the log HI partition function. """
  temp = np.exp(log_temp)
  dlog_Z_tr = 3/2
  dlog_Z_elec = chi_dis / (2 * cgs.k_B * temp)
  return dlog_Z_tr + dlog_Z_elec
    
def calc_dlog_Z_HII(log_temp):
  """ Compute the log temperature derivative of the log HII partition function. """
  temp = np.exp(log_temp)
  dlog_Z_tr = 3/2
  dlog_Z_elec = (chi_dis + 2 * chi_ion) / (2 * cgs.k_B * temp)
  return dlog_Z_tr + dlog_Z_elec

def calc_dlog_Z_HeII(log_temp):
  """ Compute the log temperature derivative of the log HeII partition function. """
  temp = np.exp(log_temp)
  dlog_Z_tr = 3/2
  dlog_Z_elec = chi_HeI / (cgs.k_B * temp)
  return dlog_Z_tr + dlog_Z_elec

def calc_dlog_Z_HeIII(log_temp):
  """ Compute the log temperature derivative of the log HeIII partition function. """
  temp = np.exp(log_temp)
  dlog_Z_tr = 3/2
  dlog_Z_elec = (chi_HeI + chi_HeII) / (cgs.k_B * temp)
  return dlog_Z_tr + dlog_Z_elec

def calc_dlog_Z(log_temp, jmax):
  """ Compute the log temperature derivative of the log partition function. """
  return np.array([
    calc_dlog_Z_H2(log_temp, jmax),
    calc_dlog_Z_HI(log_temp),
    calc_dlog_Z_HII(log_temp),
    3/2,
    calc_dlog_Z_HeII(log_temp),
    calc_dlog_Z_HeIII(log_temp),
    3/2
  ])

def calc_log_n(log_rho, log_temp, Y, jmax):
  """ Compute the log species number densities. """
  log_Z = calc_log_Z(log_temp, jmax)
  log_n_H = np.log(1 - Y) + log_rho - log_m_H
  log_n_He = np.log(Y) + log_rho - log_m_He

  # Eqs. 75-78
  log_K_dis = 2 * log_Z[HI] - log_Z[H2]
  log_K_ion = log_Z[HII] + log_Z[elec] - log_Z[HI]
  log_K_HeI = log_Z[HeII] + log_Z[elec] - log_Z[HeI]
  log_K_HeII = log_Z[HeIII] + log_Z[elec] - log_Z[HeII]

  # Eq. 85
  def func(log_n_e):
    log_n_e_plus_K_ion = logsumexp((log_n_e, log_K_ion))
    log_term1_n = log2 + 2 * log_n_e + log_n_H + log_K_ion
    log_term1_d = logsumexp([1/2 * logsumexp([2 * log_n_e_plus_K_ion, 3 * log2 - log_K_dis + log_n_H + 2 * log_n_e]), log_n_e_plus_K_ion])
    log_term2_n = logsumexp([log_K_HeI + log_n_e, log2 + log_K_HeI + log_K_HeII]) + log_n_He + 2 * log_n_e
    log_term2_d = logsumexp([2 * log_n_e, log_K_HeI + log_n_e, log_K_HeI + log_K_HeII])
    return logsumexp([log_term1_n - log_term1_d, log_term2_n - log_term2_d]) - 3 * log_n_e

  # solve for n_e by finding root of f(log_n_e)
  log_n = np.zeros((NSPEC))
  log_n_e_max = logsumexp([log_n_H, log2 + log_n_He])
  log_n_e_min = log_n_e_max - np.log(1e9)
  sign1 = np.sign(func(log_n_e_min))
  sign2 = np.sign(func(log_n_e_max))
  if sign1 == sign2 == 1.0:
    log_n[elec] = log_n_e_max
  elif sign1 == sign2 == -1.0:
    log_n[elec] = log_n_e_min
  else:
    sol = root_scalar(func, method="brentq", bracket=(log_n_e_min, log_n_e_max))
    log_n[elec] = sol.root if sol.converged else np.nan

  # solve quadratic for log_n_HI
  log_A = log2 - log_K_dis
  log_B = logsumexp([0, log_K_ion - log_n[elec]])
  log_nC = log_n_H
  log_n_HI_n = log2 + log_nC
  log_n_HI_d = logsumexp([(1/2 * logsumexp([2 * log_B, 2 * log2 + log_A + log_nC])), log_B])
  log_n[HI] = log_n_HI_n - log_n_HI_d
  
  # solve for other number densities
  log_n[HII] = log_K_ion + log_n[HI] - log_n[elec]
  log_n[H2] = 2 * log_n[HI] - log_K_dis
  log_n[HeI] = log_n_He - logsumexp([0, log_K_HeI - log_n[elec], log_K_HeI + log_K_HeII - 2 * log_n[elec]])
  log_n[HeII] = log_K_HeI + log_n[HeI] - log_n[elec]
  log_n[HeIII] = log_K_HeII + log_n[HeII] - log_n[elec]
  
  return log_n

def calc_log_thermo(log_rho, log_temp, Y, jmax, rad):
  """ Compute the log thermodynamic variables. """
  log_Z = calc_log_Z(log_temp, jmax)
  dlog_Z = calc_dlog_Z(log_temp, jmax)
  log_dlog_Z = np.log(dlog_Z)
  log_n = calc_log_n(log_rho, log_temp, Y, jmax)
  
  # thermodynamic variables
  log_pres = logsumexp(log_n) + logkB + log_temp
  log_egas = logsumexp(log_n + logkB + log_temp + log_dlog_Z)
  log_S    = logsumexp(logkB + log_n - log_rho + np.log(np.maximum(1e-12, 1 + dlog_Z - log_n + log_Z)))
  
  # add radiation contribution
  if rad:  
    log_pres = logsumexp([log_pres, logarad + 4 * log_temp - log3])
    log_egas = logsumexp([log_egas, logarad + 4 * log_temp ])
    log_S    = logsumexp([log_S,    logarad + 3 * log_temp - log_rho + 2 * log2 - log3])

  # subtract ZPE
  log_zpe = log_n[H2] + logkB + np.log(th_vib) - log2
  log_egas += np.log1p(-np.exp(log_zpe - log_egas))
  
  return [log_pres, log_egas, log_S]

def calc_all(log_rho, log_temp, Y, jmax, rad):
  """ 
  Compute the log thermodynamic variables and their derivatives.
  We compute derivatives numerically rather than solve coupled differential equations like T+13.
  """
  log_n = calc_log_n(log_rho, log_temp, Y, jmax)
  calc_log_thermo_wrapper = lambda log_rho_log_temp: calc_log_thermo(log_rho_log_temp[0], log_rho_log_temp[1], Y, jmax, rad)
  log_pres, log_egas, log_S = calc_log_thermo_wrapper([log_rho, log_temp])
  pres_rho, pres_temp, egas_rho, egas_temp, S_rho, S_temp = approx_fprime([log_rho, log_temp], calc_log_thermo_wrapper).flatten()
  gam1 = pres_rho - pres_temp * S_rho / S_temp # first adiabatic index
  gam3 = 1 - S_rho / S_temp                    # third adiabatic index
  return log_n, log_pres, log_egas, log_S, gam1, gam3

def gen_tab(rho, temp, Y=0.3, jmax=16, rad=True, do_print=True):
  """
  Args
  rho:  1D array of densities.
  temp: 1D array of temperatures.
  Y:    Helium abundance.
  jmax: Number of H2 rotational modes.
  rad:  Include radiation.
  do_print: Print as each row of table is computed
  """
  tab = SimpleNamespace()
  num_rho = rho.size
  num_temp = temp.size
  tab.log_rho, tab.log_temp = np.meshgrid(np.log(rho), np.log(temp), indexing="ij")

  # create arrays
  tab.log_n = np.zeros((NSPEC, num_rho, num_temp))
  tab.log_pres = np.zeros((num_rho, num_temp))
  tab.log_egas = np.zeros((num_rho, num_temp))
  tab.log_S = np.zeros((num_rho, num_temp))
  tab.gam1 = np.zeros((num_rho, num_temp))
  tab.gam3 = np.zeros((num_rho, num_temp))

  # do a manual loop through the grid
  for i in range(num_rho):
    if do_print: print(i, end=",")
    for j in range(num_temp):
      tab.log_n[:, i, j], tab.log_pres[i, j], tab.log_egas[i, j], tab.log_S[i, j], tab.gam1[i, j], tab.gam3[i, j] = calc_all(tab.log_rho[i, j], tab.log_temp[i, j], Y, jmax, rad)

  # compute mean molecular weight
  log_n_tot = logsumexp(tab.log_n, axis=0)
  tab.mmw = np.exp(tab.log_rho - log_n_tot - np.log(cgs.amu))

  return tab

def log_eps_func(log_temp, log_rho, log_eps, interp_log_eps, Y):
  """ Optimization function for specific internal energy. """
  mmw_low = 1 / ((1 - Y) * 1/2 + Y * 1/4)
  log_pgas = log_rho + logkB + log_temp - logmp
  log_prad = logarad + 4 * log_temp - log3
  if log_temp < 0: # assume gas pressure dominates
    return logkB - np.log(mmw_low) - np.log(cgs.amu) + log_temp + log3 - log2 - log_eps
  elif (log_prad - log_pgas) > 5: # assume radiaton pressure dominates
    return logarad + 4 * log_temp - log_rho - log_eps
  else:
    return interp_log_eps((log_temp, log_rho)) - log_eps

def log_por_func(log_temp, log_rho, log_por, interp_log_por, Y):
  """ Optimization function for pressure-over-density. """
  mmw_low = 1 / ((1 - Y) * 1/2 + Y * 1/4)
  log_pgas = log_rho + logkB + log_temp - logmp
  log_prad = logarad + 4 * log_temp - log3
  if log_temp < 0: # assume gas pressure dominates
    return logkB - np.log(mmw_low) - np.log(cgs.amu) + log_temp - log_por
  elif (log_prad - log_pgas) > 5: # assume radiaton pressure dominates
    return logarad + 4 * log_temp - log_rho - log3 - log_por
  else:
    return interp_log_por((log_temp, log_rho)) - log_por

def gen_inv_tab(tab, rho, por, eps, Y=0.3):
  """
  Args
  rho:  1D array of densities.
  por:  1D array of pressure-over-densities.
  eps:  1D array of specific energies.
  Y:    Helium abundance.
  """
  interp_log_eps = RegularGridInterpolator((tab.log_temp[0, :], tab.log_rho[:, 0]), (tab.log_egas - tab.log_rho).T)
  interp_log_por = RegularGridInterpolator((tab.log_temp[0, :], tab.log_rho[:, 0]), (tab.log_pres - tab.log_rho).T)
  interp_log_poe = RegularGridInterpolator((tab.log_temp[0, :], tab.log_rho[:, 0]), (tab.log_pres - tab.log_egas).T)
  interp_log_eop = RegularGridInterpolator((tab.log_temp[0, :], tab.log_rho[:, 0]), (tab.log_egas - tab.log_pres).T)
  interp_log_gam1 = RegularGridInterpolator((tab.log_temp[0, :], tab.log_rho[:, 0]), np.log(tab.gam1).T)

  tab_inv1 = SimpleNamespace()
  tab_inv2 = SimpleNamespace()
  num_rho = rho.size
  num_por = por.size
  num_eps = eps.size
  tab_inv1.log_rho, tab_inv1.log_eps = np.meshgrid(np.log(rho), np.log(eps), indexing="ij")
  tab_inv2.log_rho, tab_inv2.log_por = np.meshgrid(np.log(rho), np.log(por), indexing="ij")

  # create arrays
  tab_inv1.log_poe = np.zeros((num_rho, num_eps))
  tab_inv2.log_eop = np.zeros((num_rho, num_por))
  tab_inv2.log_gam1 = np.zeros((num_rho, num_por))

  for i in range(num_rho):
    for j in range(num_eps):

      sol = root_scalar(log_eps_func, args=(tab_inv1.log_rho[i, j], tab_inv1.log_eps[i, j], interp_log_eps, Y), method="brentq", bracket=(0, 10 * np.log(10)))
      log_temp = sol.root if sol.converged else np.nan
      tab_inv1.log_poe[i, j] = interp_log_poe((log_temp, tab_inv1.log_rho[i, j]))
        
    for j in range(num_por):
        
      sol = root_scalar(log_por_func, args=(tab_inv2.log_rho[i, j], tab_inv2.log_por[i, j], interp_log_por, Y), method="brentq", bracket=(0, 10 * np.log(10)))
      log_temp = sol.root if sol.converged else np.nan
      tab_inv2.log_eop[i, j] = interp_log_eop((log_temp, tab_inv2.log_eop[i, j]))
      tab_inv2.log_gam1[i, j] = interp_log_gam1((log_temp, tab_inv2.log_rho[i, j]))

  return tab_inv1, tab_inv2
