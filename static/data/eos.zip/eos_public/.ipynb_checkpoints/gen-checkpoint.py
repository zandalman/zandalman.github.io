import numpy as np
import matplotlib.pyplot as plt
from const import cgs

# molecular weights
# https://webbook.nist.gov/chemistry/name-ser/
log_m_H2 = np.log(2.01588 * cgs.amu)
log_m_H = np.log(1.00794 * cgs.amu)
log_m_He = np.log(4.002602 * cgs.amu)
log_m_e = np.log(cgs.m_e)


