This README.txt file was written on 2024-09-23 by Zachary Andalman


GENERAL INFORMATION

1. Title of Dataset: Star Formation Histories of Simulated Massive Galaxies at Cosmic Dawn

2. Author Information
	
        A. Principal Investigator Contact Information
		Name: Zachary Andalman
		Institution: Princeton University
		Email: zack.andalman@princeton.edu

	B. Associate or Co-investigator Contact Information
		Name: Romain Teyssier
		Institution: Princeton University
		Email: teyssier@princeton.edu 


3. Information about funding sources that supported the generation of the data:
        
        A. This material is based upon work supported by the National Science Foundation under Award Number 2406558 and Award Title "The Origin of the Excess of Bright Galaxies at Cosmic Dawn". 

        B. This material is based upon work supported by the U.S. Department of Energy, Office of Science, Office of Advanced Scientific Computing Research, Department of Energy Computational Science Graduate Fellowship under Award Number DE-SC0024386. 

        C. The simulations used to generate this dataset were performed on computational resources managed and supported by Princeton Research Computing, a consortium of groups including the Princeton Institute for Computational Science and Engineering (PICSciE) and the Office of Information Technology’s High Performance Computing Center and Visualization Laboratory at Princeton University.


SHARING/ACCESS INFORMATION

1. Licenses/restrictions placed on the data: Creative Commons Attribution 4.0 International

2. Links to publications that cite or use the data: Andalman et. al. in prep.


DATA & FILE OVERVIEW

1. File List: 
        fiducial.csv - Data for the fiducial model, with moderate photoionization feedback efficiency and compressive turbulence forcing.
        lowPhot.csv  - Data for a model with low photoionization feedback efficiency.
        highPhot.csv - Data for a model with high photoionization feedback efficiency.
        solTurb.csv  - Data for a model with solenoidal turbulence forcing.
        varTurb.csv  - Data for a model with variable turbulence forcing.


METHODOLOGICAL INFORMATION

1. Description of methods used for collection/generation of data: 
        The data were generated using simulations of massive galaxies at cosmic dawn in the cosmological hydrodynamics code RAMSES (Teyssier, 2002; https://www.aanda.org/articles/aa/pdf/2002/13/aa1593.pdf). The simulations focused on a galaxy inside a dark matter halo which reaches 100 billion solar masses at a redshift z = 9.

2. Methods for processing the data: 
        The data were processed from the raw simulation data using the yt-project package (https://yt-project.org/). Stellar mass and star formation rate are computed in a box of side length 5 kiloparsecs centered on the galaxy.


DATA-SPECIFIC INFORMATION

1. Number of variables: 6 

2. Number of cases/rows: 5583

3. Variable List:
        time[Myr]      - Time in megayears
        redshift       - Redshift
        Mstar[1e9Msol] - Stellar mass in billions of solar masses
        SFR[Msol/yr]   - Star formation rate in solar masses per year
        SFR10[Msol/yr] - Star formation rate averaged over the previous 10 megayears in solar masses per year
        SFR50[Msol/yr] - Star formation rate averaged over the previous 50 megayears in solar masses per year

